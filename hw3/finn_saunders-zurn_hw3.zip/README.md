1. How to complie and run:
    a. using pyinstaller: 
        pyinstaller -F <file>.py
    b. run <file> executable in dist folder

2. Command Line Usage Examples:
    sender -s 10 -d 0123456789
    sender -d imsendingpackets
    client file.txt