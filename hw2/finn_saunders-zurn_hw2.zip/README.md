1. How to complie and run:
    a. using pyinstaller: 
        pyinstaller -F <file>.py
    b. run <file> executable in dist folder

2. Command Line Usage Examples:
    my_ping -t 60 -s 64 google.com
    my_ping -c 10 -i 3 rit.edu
    my_traceroute -n google.com
    my_traceroute -s -q 1 rit.edu